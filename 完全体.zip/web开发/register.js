document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('register-form');
    const emailInput = document.getElementById('email');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const character1 = document.getElementById('character1');
    const character2 = document.getElementById('character2');

    const character1Normal = 'character1_normal.png';
    const character1Covered = 'character1_covered.png';
    const character2Normal = 'character2_normal.png';
    const character2Covered = 'character2_covered.png';

    function updateCharacterImages() {
        if (usernameInput.matches(':focus') || emailInput.matches(':focus')) {
            character1.src = character1Normal;
            character2.src = character2Normal;
        } else if (passwordInput.matches(':focus')) {
            character1.src = character1Covered;
            character2.src = character2Covered;
        }
    }

    emailInput.addEventListener('focus', updateCharacterImages);
    emailInput.addEventListener('blur', updateCharacterImages);
    usernameInput.addEventListener('focus', updateCharacterImages);
    usernameInput.addEventListener('blur', updateCharacterImages);
    passwordInput.addEventListener('focus', updateCharacterImages);
    passwordInput.addEventListener('blur', updateCharacterImages);

    registerForm.addEventListener('submit', function(event) {
        event.preventDefault();

        // 获取表单中的用户名、密码和电子邮件地址
        const username = usernameInput.value;
        const password = passwordInput.value;
        const email = emailInput.value;

        // 发送POST请求到注册API
        fetch('http://localhost:3000/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password, email })
        })
        .then(response => {
            if (!response.ok) throw new Error('Registration failed');
            return response.json();
        })
        .then(data => {
            alert('注册成功，请登录');
            window.location.href = 'login.html'; // 注册成功后跳转到登录页面
        })
        .catch(error => {
            console.error('Error:', error);
            alert('注册失败，请稍后重试');
        });
    });
});
