document.addEventListener('DOMContentLoaded', function() {
    function fetchOrdersAndUpdate() {
        const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
        const list = document.getElementById('order-history');
        if (list) {
            list.innerHTML = ''; // 清空当前列表
            orderHistory.forEach(item => {
                const listItem = document.createElement('li');
                listItem.innerHTML = `
                    <div class="item-info">
                        <img src="${item.productImage}" alt="${item.productName}" style="width: 50px; height: 50px; vertical-align: middle;">
                        <span>${item.productName} - ¥${item.productPrice} - ${item.orderTime}</span>
                        <ul>
                            ${item.reviews.map(review => `
                                <li>${review.review} - ${review.date}</li>
                            `).join('')}
                        </ul>
                    </div>
                `;
                list.appendChild(listItem);
            });
        }
    }

    window.refreshOrders = fetchOrdersAndUpdate;
    fetchOrdersAndUpdate();
});

function addOrderToLocalStorage(order) {
    const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
    orderHistory.push(order);
    localStorage.setItem('orderHistory', JSON.stringify(orderHistory));
}

function purchaseProduct(productId, productName, productPrice, productImage) {
    const newOrder = {
        productId: productId,
        productName: productName,
        productPrice: productPrice,
        productImage: productImage,
        orderTime: new Date().toISOString(),
        orderNumber: `ORD-${new Date().getTime()}-${Math.floor(Math.random() * 1000)}`,
        reviews: []
    };
    addOrderToLocalStorage(newOrder);
    alert('购买成功！');
    refreshOrders();
}
