document.addEventListener('DOMContentLoaded', function() {
    function fetchPendingReviews() {
        const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
        const pendingReviews = orderHistory.filter(order => order.reviews.length === 0);
        const list = document.getElementById('pending-reviews');
        list.innerHTML = ''; // 清空当前列表
        pendingReviews.forEach(item => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <img src="${item.productImage}" alt="${item.productName}" style="width: 50px; height: 50px; vertical-align: middle;">
                <span>${item.productName} - ¥${item.productPrice} - ${new Date(item.orderTime).toLocaleString()}</span>
                <button onclick="submitReview('${item.orderNumber}', '这是一条评论')">提交评价</button>
            `;
            list.appendChild(listItem);
        });
    }

    window.fetchPendingReviews = fetchPendingReviews;
    fetchPendingReviews();
});

function submitReview(orderNumber, reviewText) {
    const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
    const order = orderHistory.find(order => order.orderNumber === orderNumber);
    if (order) {
        order.reviews.push({ review: reviewText, date: new Date() });
        localStorage.setItem('orderHistory', JSON.stringify(orderHistory));
        alert('评价提交成功！');
        fetchPendingReviews(); // 刷新待评价列表
    } else {
        alert('订单未找到，提交评价失败');
    }
}
