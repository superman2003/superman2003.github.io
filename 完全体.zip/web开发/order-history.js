document.addEventListener('DOMContentLoaded', function() {
    const ordersPerPage = 3; // 每页最多显示3个订单
    let currentPage = 1;

    function fetchOrdersAndUpdate() {
        const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
        
        // 按时间排序，越新的记录排在前面
        orderHistory.sort((a, b) => new Date(b.orderTime) - new Date(a.orderTime));

        const list = document.getElementById('order-history');
        const pagination = document.getElementById('pagination');
        list.innerHTML = ''; // 清空当前列表
        pagination.innerHTML = ''; // 清空当前分页按钮

        const totalPages = Math.ceil(orderHistory.length / ordersPerPage);
        const start = (currentPage - 1) * ordersPerPage;
        const end = start + ordersPerPage;

        const ordersToDisplay = orderHistory.slice(start, end);
        ordersToDisplay.forEach(item => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <img src="${item.productImage}" alt="${item.productName}">
                <div class="item-info">
                    <h3>${item.productName}</h3>
                    <p>价格: ¥${item.productPrice}</p>
                    <p>订单日期: ${new Date(item.orderTime).toLocaleDateString()}</p>
                    <button onclick="reviewProduct(${item.productId})">评价</button>
                </div>
            `;
            list.appendChild(listItem);
        });

        // 上一页按钮
        const prevButton = document.createElement('button');
        prevButton.innerText = '上一页';
        if (currentPage === 1) {
            prevButton.classList.add('disabled');
        }
        prevButton.onclick = function() {
            if (currentPage > 1) {
                currentPage--;
                fetchOrdersAndUpdate();
            }
        };
        pagination.appendChild(prevButton);

        // 页码按钮
        for (let i = 1; i <= totalPages; i++) {
            const button = document.createElement('button');
            button.innerText = i;
            if (i === currentPage) {
                button.classList.add('active');
            }
            button.onclick = function() {
                currentPage = i;
                fetchOrdersAndUpdate();
            };
            pagination.appendChild(button);
        }

        // 下一页按钮
        const nextButton = document.createElement('button');
        nextButton.innerText = '下一页';
        if (currentPage === totalPages) {
            nextButton.classList.add('disabled');
        }
        nextButton.onclick = function() {
            if (currentPage < totalPages) {
                currentPage++;
                fetchOrdersAndUpdate();
            }
        };
        pagination.appendChild(nextButton);
    }

    fetchOrdersAndUpdate();
});

function reviewProduct(productId) {
    alert(`评价产品ID: ${productId}`);
}
