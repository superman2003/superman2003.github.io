const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('./models/User');
const path = require('path');

const app = express();
const port = 3000;
const secretKey = 'your_secret_key';

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb+srv://2112076433zcr:DbtpdHsjOXtAQvcs@cluster0.bvpvz3g.mongodb.net/myDatabase')
    .then(() => console.log('MongoDB 已连接'))
    .catch(err => console.error('MongoDB 连接错误:', err));

// 用户注册接口
app.post('/api/register', async (req, res) => {
    const { username, password, email } = req.body;
    try {
        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).send('用户名已存在');
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ username, password: hashedPassword, email });
        await user.save();
        res.status(201).send('用户注册成功');
    } catch (error) {
        console.error('注册时出错:', error);
        res.status(500).send('注册失败');
    }
});

// 用户登录接口
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ username });
        if (user && await bcrypt.compare(password, user.password)) {
            const token = jwt.sign({ username: user.username, _id: user._id }, secretKey, { expiresIn: '1h' });
            res.json({ token });
        } else {
            res.status(400).send('用户名或密码错误');
        }
    } catch (error) {
        console.error('登录时出错:', error);
        res.status(500).send('登录失败');
    }
});

// JWT验证中间件
function authenticateJWT(req, res, next) {
    const token = req.headers.authorization && req.headers.authorization.split(' ')[1];
    if (!token) {
        return res.status(401).json({ error: '未提供令牌' });
    }
    jwt.verify(token, secretKey, (err, user) => {
        if (err) {
            return res.status(403).json({ error: '令牌验证失败' });
        }
        req.user = user;
        next();
    });
}

// 提交评价接口
app.post('/api/submit-review', authenticateJWT, async (req, res) => {
    const { productId, review } = req.body;
    try {
        // 提交评价的逻辑
        res.status(200).send('评价发布成功');
    } catch (error) {
        console.error('提交评价时出错:', error);
        res.status(500).send('评价发布失败');
    }
});

// 获取评价接口
app.get('/api/reviews', authenticateJWT, async (req, res) => {
    try {
        // 获取评价的逻辑
        res.status(200).json({ reviews: [] });
    } catch (error) {
        console.error('获取评价时出错:', error);
        res.status(500).json({ error: '服务器内部错误' });
    }
});

// 产品数据
const products = [
    { id: 1, name: '无线鼠标', price: 50.00, description: '舒适的人体工程学设计，无线自由，持久耐用。', image: 'wireless_mouse.png' },
    { id: 2, name: '机械键盘', price: 150.00, description: '高精度机械开关，适合游戏和办公使用。', image: 'mechanical_keyboard.png' },
    { id: 3, name: '27寸显示器', price: 1200.00, description: '超高清分辨率，广视角，适合设计和办公。', image: 'monitor.png' },
    { id: 4, name: '蓝牙耳机', price: 200.00, description: '高音质音效，长续航时间，舒适佩戴。', image: 'bluetooth_headphones.png' },
    { id: 5, name: '笔记本电脑', price: 5000.00, description: '高性能处理器，超轻薄设计，适合商务和娱乐。', image: 'laptop.png' },
    { id: 6, name: '智能手表', price: 300.00, description: '多功能智能手表，健康监测，消息提醒。', image: 'smartwatch.png' },
    { id: 7, name: 'Xiaomi 14', price: 700.00, description: '徕卡光学 不负此刻。', image: 'xiaomi14.png' },
    { id: 8, name: 'iPhone 15', price: 1000.00, description: '怦然新动。', image: 'iphone15.png' },
    { id: 9, name: 'Huawei Pura 70', price: 600.00, description: '慧聚匠心,臻于至善,畅享科技之美。', image: 'huaweipura70.png' },
    { id: 10, name: '电饭煲', price: 90.00, description: '全自动操作,多功能齐聚,智能预约,触控便捷,轻松蒸煮,让每一餐都充满温馨与便利。', image: '电饭煲.png' },
    { id: 11, name: '雪糕', price: 5.00, description: '为你的夏天增添一份甜蜜的凉爽。', image: '雪糕.png' },
    { id: 12, name: 'nike短袖', price: 20.00, description: 'Done is better than perfect。', image: 'nikeT恤.png' },
    { id: 13, name: 'nike裤子', price: 30.00, description: 'Just do it!', image: 'nike裤子.png' },
];

// 获取所有产品
app.get('/api/products', (req, res) => {
    res.json(products);
});

// 获取单个产品详情
app.get('/api/products/:id', (req, res) => {
    const productId = parseInt(req.params.id);
    const product = products.find(p => p.id === productId);
    if (product) {
        res.json(product);
    } else {
        res.status(404).send('产品未找到');
    }
});

// 搜索产品接口
app.get('/api/search', (req, res) => {
    const query = req.query.q.toLowerCase();
    const filteredProducts = products.filter(product => 
        product.name.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query)
    );
    res.json(filteredProducts);
});

// 设置静态文件服务的目录，确保图片可以正确加载
app.use('/images', express.static(path.join(__dirname, 'image')));

// 提供静态文件
app.get('/order-history', (req, res) => {
    res.sendFile(path.join(__dirname, 'order-history.html'));
});

app.get('/productdetail', (req, res) => {
    res.sendFile(path.join(__dirname, 'productdetail.html'));
});

// 启动服务器
app.listen(port, () => {
    console.log(`服务器运行在 http://localhost:${port}`);
});
