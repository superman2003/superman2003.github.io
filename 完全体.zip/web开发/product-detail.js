document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('productId');

    if (productId) {
        fetch(`http://localhost:3000/api/products/${productId}`)
        .then(response => response.json())
        .then(product => {
            displayProductDetails(product);
            updateBrowsingHistory(product);
            localStorage.setItem('lastProductId', productId);

            document.getElementById('buy-button').onclick = function() {
                const productName = encodeURIComponent(product.name);
                const productPrice = product.price;
                const productImage = product.image;

                // 跳转到支付页面
                window.location.href = `pay.html?productId=${productId}&productName=${productName}&productPrice=${productPrice}&productImage=${productImage}`;
            };
        })
        .catch(error => console.error('获取产品详情时出错:', error));
    }

    function displayProductDetails(product) {
        document.getElementById('product-name').textContent = product.name;
        document.getElementById('product-price').textContent = `价格: ¥${product.price}`;
        document.getElementById('product-description').textContent = product.description;
        document.getElementById('product-image').src = `http://localhost:3000/images/${product.image}`;
    }

    function updateBrowsingHistory(product) {
        let browsingHistory = JSON.parse(localStorage.getItem('browsingHistory')) || [];
        const now = new Date().toISOString();

        const productView = {
            name: product.name,
            price: product.price,
            image: product.image,
            viewTime: now
        };

        browsingHistory.push(productView);
        localStorage.setItem('browsingHistory', JSON.stringify(browsingHistory));
    }
});
